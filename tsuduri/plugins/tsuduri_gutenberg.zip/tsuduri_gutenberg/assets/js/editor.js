const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { toggleFormat, registerFormatType, insert, applyFormat } = wp.richText;
const { RichTextToolbarButton, RichTextShortcut } = wp.editor;
const { SVG, Path } = wp.components;


(function (richText, element, editor) {

    //全角スペースボタン-------------------
    richText.registerFormatType('my-plugin/zenkaku', {
        title: '全角スペース追加',
        tagName: 'i',
        className: 'zenkaku_space',
        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton, {
                icon: 'editor-indent',
                title: '全角スペース追加',
                onClick: function () {
                    let contents = '';
                    if(! isActive){
                        contents = '&emsp;';
                        const iStart = value.start;
                        const iEnd   = value.end;
                        value = insert( value, contents, iEnd );
                        value.start = iStart;
                        value.end   = iEnd + contents.length;
                        value = applyFormat( value, {
                          type: 'my-plugin/zenkaku'
                        }, iStart, iEnd + contents.length );
                    }
                    return onChange( value );
                },
                isActive: isActive,
            });
        },
    });
    //ここまで------------------------------------------


    //三点リーダー-------------------
    richText.registerFormatType('my-plugin/santen', {
        title: '三点リーダー追加',
        tagName: 'span',
        className: 'santen',
        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton, {
                icon: 'admin-customizer',
                title: '三点リーダー追加',
                onClick: function () {
                    let contents = '';
                    if(! isActive){
                        contents = '……';
                        const spanStart = value.start;
                        const spanEnd   = value.end;
                        value = insert( value, contents, spanEnd );
                        value.start = spanStart;
                        value.end   = spanEnd + contents.length;
                        value = applyFormat( value, {
                          type: 'my-plugin/santen'
                        }, spanStart, spanEnd + contents.length );
                    }
                    return onChange( value );
                },
                isActive: isActive,
            });
        },
    });
    //ここまで------------------------------------------


    //通常ボタン-------------------
    //a
    richText.registerFormatType('my-plugin/button-normal-anker', {
        title: 'a追加',
        tagName: 'a',
        className: null,
        attributes: {
            href: '',
         },
        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton);
        },
    });

    //div
    richText.registerFormatType('my-plugin/button-normal', {
        title: '通常ボタン追加',
        tagName: 'div',
        className: 'edit_button_link',

        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton, {
                icon: 'admin-customizer',
                title: '通常ボタン追加',
                onClick: function () {
                    let raw_url = '';
                    if(! isActive){
                        raw_url = window.prompt('URLを入力してください', '') || value.text.substr( value.start, value.end -value.start );
                        const tagStart = value.start;
                        const tagEnd   = value.end;
                        //div配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-normal'
                        }, tagStart, tagEnd);
                        //a配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-normal-anker',
                            attributes: {
                                href: raw_url,
                            }
                        }, tagStart, tagEnd );
                    }
                    return onChange( value );
                },
                isActive: isActive,
            });
        },
    });
    //ここまで------------------------------------------



    //アンコン付きボタン1-------------------
    //a
    richText.registerFormatType('my-plugin/button-series-anker', {
        title: 'a追加',
        tagName: 'a',
        className: 'series_link',
        attributes: {
            href: '',
         },
        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton);
        },
    });

    //span
    richText.registerFormatType('my-plugin/button-series', {
        title: 'アイコン付きボタン1追加',
        tagName: 'span',
        className: 'series_wrap',

        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton, {
                icon: 'external',
                title: 'アイコン付きボタン1追加',
                onClick: function () {
                    let raw_url = '';
                    if(! isActive){
                        raw_url = window.prompt('URLを入力してください', '') || value.text.substr( value.start, value.end -value.start );
                        const tagStart = value.start;
                        const tagEnd   = value.end;
                        //span配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-series'
                        }, tagStart, tagEnd);
                        //a配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-series-anker',
                            attributes: {
                                href: raw_url,
                            }
                        }, tagStart, tagEnd );
                    }
                    return onChange( value );
                },
                isActive: isActive,
            });
        },
    });
    //ここまで------------------------------------------


    //アンコン付きボタン2-------------------
    //a
    richText.registerFormatType('my-plugin/button-next-anker', {
        title: 'a追加',
        tagName: 'a',
        className: 'next-story',
        attributes: {
            href: '',
         },
        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton);
        },
    });

    //span
    richText.registerFormatType('my-plugin/button-next', {
        title: 'アイコン付きボタン2追加',
        tagName: 'span',
        className: 'next_story_wrap',

        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton, {
                icon: 'external',
                title: 'アイコン付きボタン2追加',
                onClick: function () {
                    let raw_url = '';
                    if(! isActive){
                        raw_url = window.prompt('URLを入力してください', '') || value.text.substr( value.start, value.end -value.start );
                        const tagStart = value.start;
                        const tagEnd   = value.end;
                        //span配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-next'
                        }, tagStart, tagEnd);
                        //a配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-next-anker',
                            attributes: {
                                href: raw_url,
                            }
                        }, tagStart, tagEnd );
                    }
                    return onChange( value );
                },
                isActive: isActive,
            });
        },
    });
    //ここまで------------------------------------------


    //アンコン付きボタン3-------------------
    //a
    richText.registerFormatType('my-plugin/button-prev-anker', {
        title: 'a追加',
        tagName: 'a',
        className: 'prev-story',
        attributes: {
            href: '',
         },
        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton);
        },
    });

    //span
    richText.registerFormatType('my-plugin/button-prev', {
        title: 'アイコン付きボタン3追加',
        tagName: 'span',
        className: 'prev_story_wrap',

        edit: function ({isActive, value, onChange}) {
            return element.createElement(editor.RichTextToolbarButton, {
                icon: 'external',
                title: 'アイコン付きボタン3追加',
                onClick: function () {
                    let raw_url = '';
                    if(! isActive){
                        raw_url = window.prompt('URLを入力してください', '') || value.text.substr( value.start, value.end -value.start );
                        const tagStart = value.start;
                        const tagEnd   = value.end;
                        //span配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-prev'
                        }, tagStart, tagEnd);
                        //a配置
                        value = applyFormat( value, {
                          type: 'my-plugin/button-prev-anker',
                            attributes: {
                                href: raw_url,
                            }
                        }, tagStart, tagEnd );
                    }
                    return onChange( value );
                },
                isActive: isActive,
            });
        },
    });
    //ここまで------------------------------------------

}(
    window.wp.richText,
    window.wp.element,
    window.wp.editor
));
