<?php

/**
 * Plugin Name: tsuduri_gutenberg
 * Description: このプラグインはWPテーマ『綴』専用の『Gutenberg』拡張用プラグインです。使用するには有効化してください。
 * Version: 1.0.0
 * Author: MIO
 */


add_action( 'enqueue_block_editor_assets', function () {
   wp_enqueue_style( 'tsuduri_gutenberg', plugins_url( 'assets/css/editor.css', __FILE__ ) );
   wp_enqueue_script( 'tsuduri_gutenberg', plugins_url( 'assets/js/editor.js', __FILE__ ), [
      'wp-element',
      'wp-rich-text',
      'wp-editor',
   ] );
   wp_localize_script( 'tsuduri_gutenberg', 'tsuduri_gutenberg_obj', [
      'title' => 'tsuduri_gutenberg',
      'class' => 'tsuduri_gutenberg',
   ] );
} );
