/**
 * Bundled assets for format library.
 */

import './formats/_small';
import './formats/_cite';
import './formats/_quote';
import './formats/_ruby';
